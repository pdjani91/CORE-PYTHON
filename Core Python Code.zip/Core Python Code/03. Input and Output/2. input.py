# getting user input without prompt
name = input()
print(name)

# Getting user input with prompt
nm = input("What is Your Name: ")
print(nm)

nm = input("What is Your Name: ")
print("You name is:", nm)

# Getting input and convert it into integer
mobile = input("Enter Mobile Number: ")
print(type(mobile))
mb = int(mobile)
print(mb)
print(type(mb))

reg = int(input("Enter Registration Number: "))
print(reg)
