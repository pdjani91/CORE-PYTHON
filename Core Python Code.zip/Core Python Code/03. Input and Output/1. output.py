# print string with double quotes
print("Welcome to Geeky Shows")

# print blank line
print()

# print string with Single quotes
print('Welcome to Geeky Shows')

# print each word in same line becoz inside one print function
print("Like", "Share", "Subscribe")

# print integer
print(10)

# prints in separate line
print("Welcome")
print("to")
print("Geeky Shows")

# print list
data = [10, 20, -50, 21.3, 'Geekyshows']
print(data)

# print with separator
print("Like", "Share", "Subscribe", sep="***")

# print with end 'space'
print("Welcome", end="")
print("to", end="")
print("GeekyShows")

# print with end 'tab'
print("We", end="\t")
print("to", end="\t")
print("Ge")

# print variable value
a = 10
print(a)

# print variable value with separator
x = 20
y = 30
print(x, y)
print(x, y, sep=',')

# print with integer and string
m = 40
print("Value: ", m)

# print with integer and string
name = "Rahul"
age = 62
print("My Name is ", name, "and My age is ", age)

