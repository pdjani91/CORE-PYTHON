# Addition
# print(4+2)
a = 4
b = 2
total = a + b
print(total)

# Subtraction
#print(8-2)
a = 4
b = 2
total = a - b
print(total)

# Multiplication
#print(4*2)
a = 6
b = 3
value = a * b
print(value)

# Divison
#print(4/2)
a = 4
b = 2
value = a / b
print(value)
print(type(value))

# Modulus
#print(5%2)
a = 5
b = 2
value = a % b
print(value) 

# Exponent
#print(5**2)
a = 5
b = 2
value = a**b
print(value)

# Floor Division Positive
#print(5//2)
a = 5
b = 2
value = a//b
print(value)

# Floor Division Negative
#print(-5//2)
a = -5
b = 2
value = a//b
print(value)