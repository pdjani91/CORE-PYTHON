# It will show TypeError, you can not modify String
str1 = "GeekyShows"
str1[4] = "i"
for c in str1:
	print(c)

