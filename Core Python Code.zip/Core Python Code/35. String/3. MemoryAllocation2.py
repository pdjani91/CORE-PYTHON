str1 = "GeekyShows"
print("str1=", id(str1))
str1 = "Python"
print("str1=", id(str1))