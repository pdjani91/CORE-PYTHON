from numpy import *

a = array([100, 200, 13, 0, 400, 500, 0])
result = nonzero(a)
print(result)
