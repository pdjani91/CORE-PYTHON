#index() Method
a = [10, 20, 30, 10, 90, 'Geekyshows']
num = a.index(10)
print(num)