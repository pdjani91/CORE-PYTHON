a = [10, 20, -50, 21.3, 'Geekyshows']
print(a, id(a))
print(a[1])
a[1] = 40
print(a[1])
print(a, id(a))