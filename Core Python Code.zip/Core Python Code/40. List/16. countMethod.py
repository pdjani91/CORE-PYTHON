#count() Method
a = [10, 20, 30, 10, 90, 'GeekyShows']
num = a.count(10)
print(num)