# Sets - clear() Method

a = {10, 20, 'GeekyShows'}
print("Before Clear",a)
print(id(a))
print()

a.clear()

print("After Clear",a)
print(id(a))
