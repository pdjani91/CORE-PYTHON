# Break Statement
for i in range(10):
	if(i == 5):
		break
	print(i)
print("Rest of the Code")

print("****************")

# Continue Statement
for i in range(10):
	if(i == 5):
		continue
	print(i)
print("Rest of the Code")

