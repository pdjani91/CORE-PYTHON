a = int(input("Enter Number Greater than 2: "))
if(a > 2):
	print("You have Entered:", a)