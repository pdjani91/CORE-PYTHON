# Passing List to Function
def show(l):
	print(l)
	print(type(l))
	for i in l:
		print(i)

lst = [10, 20, 30, 'GeekyShows']
show(lst)



