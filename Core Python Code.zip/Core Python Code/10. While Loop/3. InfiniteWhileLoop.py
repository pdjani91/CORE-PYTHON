# Infinite While Loop
while True:
	print("Geeky Shows")
print("Rest of the Code")

# Infinite While Loop
i = 0
while True:
	i+=1
	print(i)
	if(i == 5):
		break
print("Rest of the Code")