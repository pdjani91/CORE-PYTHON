# Write once and use it as many time as you need
# Defining Function one time
def disp():
	name = "GeekyShows"
	print("Welcome to", name)

# Calling Function as many time as we need
disp()
disp()
disp()

#Divide Large task into many small task, helpful for debuging code
# Seprate Function for Addition
def add():
	x = 10
	y = 20
	c = x + y
	print(c)
	
add()

# Seprate Function for Subtraction
def sub():
	x = 10
	y = 20
	c = y - x
	print(c)
	
sub()

	

