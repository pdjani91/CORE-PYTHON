# len() Function
a = "GeekyShows"
b = [10, 20, 30]
c = (10, 20, 30, 40)
d = {10, 20, 30, 40, 50}
e = {101:'Rahul', 102:'Raj', 103:'Sonam'}
f = [[10, 20], [30, 40], [60, 70]]
g = [(101, 'Rahul'), (102, 'Raj'), (103, 'Sonam')]
print(len(a))
print(len(b))
print(len(c))
print(len(d))
print(len(e))
print(len(f))
print(len(g))