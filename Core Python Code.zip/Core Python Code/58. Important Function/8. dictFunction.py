# dict() Function
a = [(101, 'Rahul'), (102, 'Raj'), (103, 'Sonam')]
print(a)
print(type(a))
new_a = dict(a)
print(new_a)
print(type(new_a))
print()
