# flatten ( ) Function
#2D to 1D
from numpy import *
e = array([[1, 2, 3], [4, 5, 6]])
f = e.flatten()
print(e)
print(f)
