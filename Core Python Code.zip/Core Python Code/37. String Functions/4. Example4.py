print("****** isspace Function ******")
name = "  "
str1 = name.isspace()
print(name)
print(str1)
