# Testing Keys

stu = {101: 'Rahul', 102: 'Raj', 103: 'Sonam' }

print(101 in stu)

print(100 in stu)

print(100 not in stu)

print(101 not in stu)


