# Nested List Comprehension

lst =[[i*j for j in range(4,7)] for i in range(6,8)]
print(lst)

# Below Code is only for explanation you can ommit 
a = [[24, 30, 36], [28, 35, 42]]
for i in range(6,8):
	for j in range(4,7):
		pass
		