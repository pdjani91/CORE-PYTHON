# If elif else Statement
day = "Tuesday"
if (day == "Monday"):
	print("Today is Monday")
elif (day == "Tuesday"):
	print("Today is Tuesday")
elif (day == "Wednesday"):
	print("Today is Wednesday")
else:
	print("Today is Holiday")


# If elif else with User Input
day = input("Enter Day: ")
if day == "Monday":
	print("Today is Monday")
elif day == "Tuesday":
	print("Today is Tuesday")
elif day == "Wednesday":
	print("Today is Wednesday")
else:
	print("Today is Holiday")